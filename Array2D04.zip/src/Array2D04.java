/*
문제4) 2차원 배열 scores에 학생 수를 입력하고 학생수에 따라 과목수를 입력하여, 각 학생의 과목에 대하여 점수를 입력한 후
각 학생에 대한 총점, 평균, 학점, 석차를 출력하시오.
- 평균은 소수점 둘째 자리까지 반올림하여 출력하시오.
- 학점은 평균이 90점이상이면 A, 80점 이상이면 B, 70점 이상이면 C, 60점 이상이면 D, 60점 미만이면 F로 출력하시오.
- 석차는 총점을 기준으로 정하시오.
- 마지막 줄에는 각 과목에 대한 평균이 출력되도록 하시오.
 */
import java.util.Scanner;
public class Array2D04 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("학생 수를 입력하시오: ");
		int stu = sc.nextInt();
		
		int[][] scores = new int [stu][];
		
		// 2차원 배열 -> stu명의 학생에 대한 성적, stu행 subject열
		System.out.println("각 학생의 과목 수를 입력하시오.(3이하의 숫자만 입력)");
		for(int i=0; i<stu; i++) {
			System.out.printf("%d 번째 학생의 과목 수: ", i + 1);
			int sub = sc.nextInt();
			scores[i] = new int[sub+1];
		}
		
		// 각 과목에대한 점수 입력받기
		for(int i=0; i<scores.length; i++) {    // 학생의 명수만큼 반복
			for(int j=0; j<scores[i].length -1; j++) {		// 마지막 총점칸 제외하고 각 학생의 과목개수만큼 반복
				switch(j) {			
				case 0:
					System.out.printf("%d번 학생의 국어점수 입력: ", i + 1);
					break;			
				case 1:
					System.out.printf("%d번 학생의 영어점수 입력: ", i + 1);
					break;
				case 2:
					System.out.printf("%d번 학생의 수학점수 입력: ", i + 1);
					break;
				}
				scores[i][j] = sc.nextInt();
			}
		}

		// 1차원 배열 -> 각 학생의 평균, 실수형 배열
		double[] aves = new double[stu];
		
		// 1차원 배열 -> 학생의 학점, 문자형 배열
		char[] grds = new char[stu];
		
		// 1차원 배열 -> 학생의 석차
		// 석차는 값을 1로 초기화를 하고, 자신보다 큰 값이 있을때 자신의 값에 1을 더한다
		int[] ranks = new int[stu];
		for(int i=0; i<ranks.length;i++) {
			ranks[i] = 1; //배열의 모든 값을 1로 초기화
		}
		
		// 1차원 배열 -> 국어, 영어, 수학, 총점, 평균의 전체평균
		double[] t_aves = new double[5];
		
		// 1차원 배열 -> 3개의 과목
		String[] subjects = new String[] {"KOR", "ENG", "MAT", "TOT", "AVE", "GRD", "RANK"};
		System.out.printf(" %3s |", "NO");
		for(int i=0; i<subjects.length; i++) {
			System.out.printf("%6s | ", subjects[i]);
		}
		System.out.println();
		
		// 라인 출력
		System.out.print("-----");
		for(int i=0; i<subjects.length; i++) {
			System.out.print("---------");
		}
		System.out.println();
		
		// 총점 + 평균계산 + 학점구하기
		for (int i = 0; i < scores.length; i++) {
			int sum = 0;
			// 해당 학생의 과목 수만큼 반복 (마지막 방은 총점이 들어갈 자리이므로 -1) 
			for (int j = 0; j<scores[i].length-1; j++) {
				sum += scores[i][j];
			}
			// scores[i]의 가장 마지막 방에 총점 저장
			scores[i][scores[i].length-1] = sum; 
			// 평균 계산 
			aves[i] = (double)scores[i][scores[i].length-1]/(scores[i].length-1);
			// 학점 계산
			switch((int)(aves[i]/10)) {
			case 10:
			case 9: grds[i] = 'A'; break;
			case 8: grds[i] = 'B'; break;
			case 7: grds[i] = 'C'; break;
			case 6: grds[i] = 'D'; break;
			default: grds[i] = 'F';
			}
		}
		// 석차 계산 - i: 자신, j: 다른 학생
		for(int i=0; i<scores.length; i++) {
			for(int j=0; j<scores.length; j++) {
				if(scores[i][scores[i].length - 1] < scores[j][scores[j].length - 1]) {
					++ranks[i];
				}
			}
		}
		// 2차원 배열의 출력, 1차원 배열 출력
		for(int i=0; i<scores.length; i++) {
			System.out.printf(" %03d |", i+1);
				for(int j=0; j<3; j++) {			// 국어(0), 영어(1), 수학(2) 자리를 돌며 점수가 있으면 출력, 없으면 - 출력
					if (j < scores[i].length - 1) {
						System.out.printf("%6d | ", scores[i][j]);
					} else {
						System.out.printf("%6s | ", "-");
					}
				}
			System.out.printf("%6d | %6.2f | %6c | %6d |\n",scores[i][scores[i].length - 1], aves[i], grds[i], ranks[i]);
		}
		// 라인 출력
		System.out.print("-----");
		for(int i=0; i<subjects.length; i++) {
			System.out.print("---------");
		}
		System.out.println();
		
		// 0. 칸맞추기
		System.out.printf(" %3s |", "AVE");
		// 1. 국어, 영어, 수학, 총점의 평균계산
		int[] subCnt = new int[3]; // 과목별 학생 수 카운트용
		for(int i=0; i<scores.length; i++) {
			for(int j=0; j<3; j++) {
				if (j < scores[i].length - 1) {
					t_aves[j] += scores[i][j];
					subCnt[j]++;				
				}
			}
			t_aves[3] += scores[i][scores[i].length - 1]; // 총점 누적
			t_aves[4] += aves[i];                         // 평균 누적
		}
		// 3. 최종 평균 구하기 (둘째자리 반올림)
		for(int i=0; i<3; i++) {
			if (subCnt[i] > 0) {
				t_aves[i] = t_aves[i] / subCnt[i];
			}
		}
		t_aves[3] = t_aves[3] / stu;
		t_aves[4] = t_aves[4] / stu;
		
		for(int i=0; i<t_aves.length; i++) {
			System.out.printf("%6.2f | ", t_aves[i]);
		}
		System.out.printf("%6s | %6s |\n", "-", "-");
		
		sc.close();
		//end
	}
}